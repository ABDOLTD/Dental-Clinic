from django.contrib import messages
from django.contrib.auth.views import LoginView, LogoutView
from django.shortcuts import get_object_or_404, redirect, render
from django.urls import reverse_lazy

from .decorators import role_required
from .forms import StaffCreateForm, StyledAuthenticationForm
from .models import User


class ClinicLoginView(LoginView):
    template_name = 'accounts/login.html'
    authentication_form = StyledAuthenticationForm
    redirect_authenticated_user = True


class ClinicLogoutView(LogoutView):
    next_page = reverse_lazy('accounts:login')


@role_required(User.Role.ADMIN)
def staff_list(request):
    staff = User.objects.all().order_by('role', 'first_name')
    return render(request, 'accounts/staff_list.html', {'staff': staff})


@role_required(User.Role.ADMIN)
def staff_create(request):
    if request.method == 'POST':
        form = StaffCreateForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Staff member added successfully.')
            return redirect('accounts:staff_list')
    else:
        form = StaffCreateForm()
    return render(request, 'accounts/staff_form.html', {'form': form})


@role_required(User.Role.ADMIN)
def staff_toggle_active(request, pk):
    staff = get_object_or_404(User, pk=pk)
    if staff != request.user:
        staff.is_active = not staff.is_active
        staff.save(update_fields=['is_active'])
        messages.success(request, f'{staff} is now {"active" if staff.is_active else "inactive"}.')
    return redirect('accounts:staff_list')
