from django.contrib.auth.models import AbstractUser
from django.db import models


class User(AbstractUser):
    class Role(models.TextChoices):
        ADMIN = 'ADMIN', 'Admin'
        RECEPTION = 'RECEPTION', 'Receptionist'
        DOCTOR = 'DOCTOR', 'Doctor'

    role = models.CharField(max_length=20, choices=Role.choices, default=Role.RECEPTION)
    phone = models.CharField(max_length=30, blank=True)
    specialty = models.CharField(max_length=100, blank=True, help_text='e.g. Orthodontist, General Dentist')

    @property
    def is_admin_role(self):
        return self.role == self.Role.ADMIN

    @property
    def is_reception_role(self):
        return self.role == self.Role.RECEPTION

    @property
    def is_doctor_role(self):
        return self.role == self.Role.DOCTOR

    @property
    def initials(self):
        parts = [p[0] for p in [self.first_name, self.last_name] if p]
        return ''.join(parts).upper() or self.username[:2].upper()

    def __str__(self):
        return self.get_full_name() or self.username
