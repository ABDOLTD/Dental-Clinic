from django.urls import path

from . import views

app_name = 'accounts'

urlpatterns = [
    path('login/', views.ClinicLoginView.as_view(), name='login'),
    path('logout/', views.ClinicLogoutView.as_view(), name='logout'),
    path('staff/', views.staff_list, name='staff_list'),
    path('staff/add/', views.staff_create, name='staff_create'),
    path('staff/<int:pk>/toggle/', views.staff_toggle_active, name='staff_toggle_active'),
]
