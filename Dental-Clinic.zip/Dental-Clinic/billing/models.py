from decimal import Decimal

from django.conf import settings
from django.db import models
from django.urls import reverse

from patients.models import Patient
from treatments.models import TreatmentRecord


class Invoice(models.Model):
    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='invoices')
    treatment_records = models.ManyToManyField(TreatmentRecord, related_name='invoices', blank=True)
    issued_date = models.DateField()
    due_date = models.DateField(null=True, blank=True)
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='created_invoices',
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-issued_date', '-created_at']

    def __str__(self):
        return f'Invoice #{self.pk} - {self.patient}'

    def get_absolute_url(self):
        return reverse('billing:invoice_detail', args=[self.pk])

    @property
    def total_amount(self):
        return self.treatment_records.aggregate(total=models.Sum('cost'))['total'] or Decimal('0.00')

    @property
    def amount_paid(self):
        return self.payments.aggregate(total=models.Sum('amount'))['total'] or Decimal('0.00')

    @property
    def balance_due(self):
        return self.total_amount - self.amount_paid

    @property
    def status(self):
        if self.balance_due <= 0 and self.total_amount > 0:
            return 'PAID'
        if self.amount_paid > 0:
            return 'PARTIAL'
        return 'UNPAID'

    @property
    def status_color(self):
        return {
            'PAID': 'bg-primary/10 text-primary',
            'PARTIAL': 'bg-amber-100 text-amber-700',
            'UNPAID': 'bg-rose-100 text-rose-700',
        }[self.status]


class Payment(models.Model):
    class Method(models.TextChoices):
        CASH = 'CASH', 'Cash'
        CARD = 'CARD', 'Card'
        INSURANCE = 'INSURANCE', 'Insurance'
        TRANSFER = 'TRANSFER', 'Bank Transfer'

    invoice = models.ForeignKey(Invoice, on_delete=models.CASCADE, related_name='payments')
    amount = models.DecimalField(max_digits=9, decimal_places=2)
    method = models.CharField(max_length=20, choices=Method.choices, default=Method.CASH)
    date = models.DateField()
    received_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='received_payments',
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date', '-created_at']

    def __str__(self):
        return f'{self.amount} for Invoice #{self.invoice_id}'
