from datetime import date

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render

from accounts.decorators import role_required
from accounts.models import User
from patients.models import Patient
from .forms import InvoiceForm, PaymentForm
from .models import Invoice


@login_required
def invoice_list(request):
    invoices = Invoice.objects.select_related('patient')

    patient_id = request.GET.get('patient')
    if patient_id:
        invoices = invoices.filter(patient_id=patient_id)

    invoices = list(invoices)
    status_filter = request.GET.get('status')
    if status_filter:
        invoices = [inv for inv in invoices if inv.status == status_filter]

    return render(request, 'billing/invoice_list.html', {'invoices': invoices, 'active_nav': 'billing', 'selected_status': status_filter})


@login_required
def invoice_detail(request, pk):
    invoice = get_object_or_404(Invoice.objects.select_related('patient'), pk=pk)
    if request.method == 'POST':
        if request.user.is_doctor_role:
            messages.error(request, 'Doctors can view invoices but cannot record payments.')
            return redirect('billing:invoice_detail', pk=pk)
        form = PaymentForm(request.POST)
        if form.is_valid():
            payment = form.save(commit=False)
            payment.invoice = invoice
            payment.received_by = request.user
            payment.save()
            messages.success(request, 'Payment recorded.')
            return redirect('billing:invoice_detail', pk=pk)
    else:
        form = PaymentForm(initial={'date': date.today(), 'amount': invoice.balance_due})

    return render(request, 'billing/invoice_detail.html', {
        'invoice': invoice,
        'form': form,
        'active_nav': 'billing',
    })


@role_required(User.Role.ADMIN, User.Role.RECEPTION)
def invoice_create(request):
    patient_id = request.GET.get('patient') or request.POST.get('patient')
    if not patient_id:
        return render(request, 'billing/invoice_select_patient.html', {
            'patients': Patient.objects.all(),
            'active_nav': 'billing',
        })

    patient = get_object_or_404(Patient, pk=patient_id)

    if request.method == 'POST':
        form = InvoiceForm(request.POST, patient=patient)
        if form.is_valid():
            invoice = form.save(commit=False)
            invoice.patient = patient
            invoice.created_by = request.user
            invoice.save()
            form.save_m2m()
            messages.success(request, f'Invoice #{invoice.pk} created for {patient.full_name}.')
            return redirect('billing:invoice_detail', pk=invoice.pk)
    else:
        form = InvoiceForm(initial={'issued_date': date.today()}, patient=patient)

    return render(request, 'billing/invoice_form.html', {
        'form': form,
        'patient': patient,
        'active_nav': 'billing',
    })
