from django import forms

from dental_clinic.form_utils import CHECKBOX_CLASSES, INPUT_CLASSES, TEXTAREA_CLASSES
from treatments.models import TreatmentRecord
from .models import Invoice, Payment


class InvoiceForm(forms.ModelForm):
    treatment_records = forms.ModelMultipleChoiceField(
        queryset=TreatmentRecord.objects.none(),
        widget=forms.CheckboxSelectMultiple(attrs={'class': CHECKBOX_CLASSES}),
        required=True,
    )

    class Meta:
        model = Invoice
        fields = ['issued_date', 'due_date', 'notes', 'treatment_records']
        widgets = {
            'issued_date': forms.DateInput(attrs={'class': INPUT_CLASSES, 'type': 'date'}),
            'due_date': forms.DateInput(attrs={'class': INPUT_CLASSES, 'type': 'date'}),
            'notes': forms.Textarea(attrs={'class': TEXTAREA_CLASSES}),
        }

    def __init__(self, *args, patient=None, **kwargs):
        super().__init__(*args, **kwargs)
        qs = TreatmentRecord.objects.filter(patient=patient, invoices__isnull=True)
        if self.instance.pk:
            qs = qs | self.instance.treatment_records.all()
        self.fields['treatment_records'].queryset = qs.distinct()


class PaymentForm(forms.ModelForm):
    class Meta:
        model = Payment
        fields = ['amount', 'method', 'date']
        widgets = {
            'amount': forms.NumberInput(attrs={'class': INPUT_CLASSES, 'step': '0.01'}),
            'method': forms.Select(attrs={'class': INPUT_CLASSES}),
            'date': forms.DateInput(attrs={'class': INPUT_CLASSES, 'type': 'date'}),
        }
