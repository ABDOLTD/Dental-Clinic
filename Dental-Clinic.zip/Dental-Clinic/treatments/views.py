from datetime import date

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render

from accounts.decorators import role_required
from accounts.models import User
from .forms import TreatmentForm, TreatmentRecordForm
from .models import Treatment, TreatmentRecord


@login_required
def catalog_list(request):
    treatments = Treatment.objects.all()
    return render(request, 'treatments/catalog_list.html', {'treatments': treatments, 'active_nav': 'treatments'})


@role_required(User.Role.ADMIN)
def catalog_create(request):
    if request.method == 'POST':
        form = TreatmentForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, 'Treatment added to catalog.')
            return redirect('treatments:catalog_list')
    else:
        form = TreatmentForm()
    return render(request, 'treatments/catalog_form.html', {'form': form, 'active_nav': 'treatments', 'title': 'Add Treatment'})


@role_required(User.Role.ADMIN)
def catalog_edit(request, pk):
    treatment = get_object_or_404(Treatment, pk=pk)
    if request.method == 'POST':
        form = TreatmentForm(request.POST, instance=treatment)
        if form.is_valid():
            form.save()
            messages.success(request, 'Treatment updated.')
            return redirect('treatments:catalog_list')
    else:
        form = TreatmentForm(instance=treatment)
    return render(request, 'treatments/catalog_form.html', {'form': form, 'active_nav': 'treatments', 'title': 'Edit Treatment'})


@login_required
def record_list(request):
    records = TreatmentRecord.objects.select_related('patient', 'doctor', 'treatment')

    if request.user.is_doctor_role:
        records = records.filter(doctor=request.user)

    patient_id = request.GET.get('patient')
    if patient_id:
        records = records.filter(patient_id=patient_id)

    return render(request, 'treatments/record_list.html', {'records': records, 'active_nav': 'treatments'})


@login_required
def record_detail(request, pk):
    record = get_object_or_404(TreatmentRecord.objects.select_related('patient', 'doctor', 'treatment'), pk=pk)
    return render(request, 'treatments/record_detail.html', {'record': record, 'active_nav': 'treatments'})


@role_required(User.Role.ADMIN, User.Role.DOCTOR)
def record_create(request):
    initial = {'date': date.today()}
    if request.GET.get('patient'):
        initial['patient'] = request.GET['patient']
    if request.GET.get('appointment'):
        initial['appointment'] = request.GET['appointment']
    if request.user.is_doctor_role:
        initial['doctor'] = request.user.pk

    if request.method == 'POST':
        form = TreatmentRecordForm(request.POST)
        if form.is_valid():
            record = form.save(commit=False)
            if not record.cost:
                record.cost = record.treatment.default_price
            record.save()
            messages.success(request, 'Treatment recorded.')
            return redirect('treatments:record_detail', pk=record.pk)
    else:
        form = TreatmentRecordForm(initial=initial)
        if request.user.is_doctor_role:
            form.fields['doctor'].queryset = form.fields['doctor'].queryset.filter(pk=request.user.pk)

    return render(request, 'treatments/record_form.html', {'form': form, 'active_nav': 'treatments', 'title': 'Log Treatment'})


@role_required(User.Role.ADMIN, User.Role.DOCTOR)
def record_edit(request, pk):
    record = get_object_or_404(TreatmentRecord, pk=pk)
    if request.user.is_doctor_role and record.doctor != request.user:
        messages.error(request, 'You can only edit your own treatment records.')
        return redirect('treatments:record_list')

    if request.method == 'POST':
        form = TreatmentRecordForm(request.POST, instance=record)
        if form.is_valid():
            form.save()
            messages.success(request, 'Treatment record updated.')
            return redirect('treatments:record_detail', pk=record.pk)
    else:
        form = TreatmentRecordForm(instance=record)
    return render(request, 'treatments/record_form.html', {'form': form, 'active_nav': 'treatments', 'title': 'Edit Treatment Record'})


@role_required(User.Role.ADMIN)
def record_delete(request, pk):
    record = get_object_or_404(TreatmentRecord, pk=pk)
    if request.method == 'POST':
        record.delete()
        messages.success(request, 'Treatment record deleted.')
        return redirect('treatments:record_list')
    return render(request, 'treatments/record_confirm_delete.html', {'record': record, 'active_nav': 'treatments'})
