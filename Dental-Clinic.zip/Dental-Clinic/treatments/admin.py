from django.contrib import admin

from .models import Treatment, TreatmentRecord


@admin.register(Treatment)
class TreatmentAdmin(admin.ModelAdmin):
    list_display = ('name', 'category', 'default_price', 'is_active')
    list_filter = ('category', 'is_active')


@admin.register(TreatmentRecord)
class TreatmentRecordAdmin(admin.ModelAdmin):
    list_display = ('patient', 'treatment', 'doctor', 'date', 'cost')
    list_filter = ('treatment', 'doctor')
