from django.urls import path

from . import views

app_name = 'treatments'

urlpatterns = [
    path('', views.record_list, name='record_list'),
    path('add/', views.record_create, name='record_create'),
    path('<int:pk>/', views.record_detail, name='record_detail'),
    path('<int:pk>/edit/', views.record_edit, name='record_edit'),
    path('<int:pk>/delete/', views.record_delete, name='record_delete'),
    path('catalog/', views.catalog_list, name='catalog_list'),
    path('catalog/add/', views.catalog_create, name='catalog_create'),
    path('catalog/<int:pk>/edit/', views.catalog_edit, name='catalog_edit'),
]
