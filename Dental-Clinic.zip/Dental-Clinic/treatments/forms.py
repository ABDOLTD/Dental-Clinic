from django import forms

from accounts.models import User
from appointments.models import Appointment
from dental_clinic.form_utils import INPUT_CLASSES, TEXTAREA_CLASSES
from patients.models import Patient
from .models import Treatment, TreatmentRecord


class TreatmentForm(forms.ModelForm):
    class Meta:
        model = Treatment
        fields = ['name', 'category', 'description', 'default_price', 'is_active']
        widgets = {
            'name': forms.TextInput(attrs={'class': INPUT_CLASSES}),
            'category': forms.Select(attrs={'class': INPUT_CLASSES}),
            'description': forms.Textarea(attrs={'class': TEXTAREA_CLASSES}),
            'default_price': forms.NumberInput(attrs={'class': INPUT_CLASSES, 'step': '0.01'}),
            'is_active': forms.CheckboxInput(attrs={'class': 'w-4 h-4 rounded border-slate-300 text-primary focus:ring-primary/30'}),
        }


class TreatmentRecordForm(forms.ModelForm):
    patient = forms.ModelChoiceField(
        queryset=Patient.objects.all(),
        widget=forms.Select(attrs={'class': INPUT_CLASSES}),
    )
    doctor = forms.ModelChoiceField(
        queryset=User.objects.filter(role=User.Role.DOCTOR, is_active=True),
        widget=forms.Select(attrs={'class': INPUT_CLASSES}),
    )
    appointment = forms.ModelChoiceField(
        queryset=Appointment.objects.all(), required=False,
        widget=forms.Select(attrs={'class': INPUT_CLASSES}),
    )

    class Meta:
        model = TreatmentRecord
        fields = ['patient', 'doctor', 'treatment', 'appointment', 'tooth', 'cost', 'notes', 'date']
        widgets = {
            'treatment': forms.Select(attrs={'class': INPUT_CLASSES}),
            'tooth': forms.TextInput(attrs={'class': INPUT_CLASSES, 'placeholder': 'e.g. #14 (optional)'}),
            'cost': forms.NumberInput(attrs={'class': INPUT_CLASSES, 'step': '0.01'}),
            'notes': forms.Textarea(attrs={'class': TEXTAREA_CLASSES}),
            'date': forms.DateInput(attrs={'class': INPUT_CLASSES, 'type': 'date'}),
        }
