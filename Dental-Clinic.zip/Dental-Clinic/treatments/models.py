from django.conf import settings
from django.db import models
from django.urls import reverse

from appointments.models import Appointment
from patients.models import Patient


class Treatment(models.Model):
    """Catalog of services the clinic offers (e.g. Cleaning, Filling, Root Canal)."""

    class Category(models.TextChoices):
        PREVENTIVE = 'PREVENTIVE', 'Preventive'
        RESTORATIVE = 'RESTORATIVE', 'Restorative'
        SURGICAL = 'SURGICAL', 'Surgical'
        COSMETIC = 'COSMETIC', 'Cosmetic'
        ORTHODONTIC = 'ORTHODONTIC', 'Orthodontic'
        DIAGNOSTIC = 'DIAGNOSTIC', 'Diagnostic'

    name = models.CharField(max_length=150)
    category = models.CharField(max_length=20, choices=Category.choices, default=Category.PREVENTIVE)
    description = models.TextField(blank=True)
    default_price = models.DecimalField(max_digits=9, decimal_places=2)
    is_active = models.BooleanField(default=True)

    class Meta:
        ordering = ['category', 'name']

    def __str__(self):
        return self.name


class TreatmentRecord(models.Model):
    """A treatment actually performed on a patient during a visit."""

    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='treatment_records')
    doctor = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='treatment_records',
        limit_choices_to={'role': 'DOCTOR'},
    )
    treatment = models.ForeignKey(Treatment, on_delete=models.PROTECT, related_name='records')
    appointment = models.ForeignKey(
        Appointment, on_delete=models.SET_NULL, null=True, blank=True, related_name='treatment_records',
    )
    tooth = models.CharField(max_length=20, blank=True, help_text='Optional tooth number/label, e.g. #14')
    cost = models.DecimalField(max_digits=9, decimal_places=2)
    notes = models.TextField(blank=True)
    date = models.DateField()
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date', '-created_at']

    def __str__(self):
        return f'{self.treatment} for {self.patient} on {self.date}'

    def get_absolute_url(self):
        return reverse('treatments:record_detail', args=[self.pk])

    def save(self, *args, **kwargs):
        if not self.cost and self.treatment_id:
            self.cost = self.treatment.default_price
        super().save(*args, **kwargs)
