from django.contrib import admin
from django.urls import include, path

urlpatterns = [
    path('admin/', admin.site.urls),
    path('accounts/', include('accounts.urls')),
    path('patients/', include('patients.urls')),
    path('appointments/', include('appointments.urls')),
    path('treatments/', include('treatments.urls')),
    path('billing/', include('billing.urls')),
    path('', include('core.urls')),
]
