INPUT_CLASSES = (
    'w-full rounded-xl border border-slate-200 bg-slate-50 px-4 py-2.5 text-slate-800 '
    'focus:border-primary focus:bg-white focus:outline-none focus:ring-2 focus:ring-primary/30 transition'
)

TEXTAREA_CLASSES = INPUT_CLASSES + ' min-h-[6rem]'

CHECKBOX_CLASSES = 'w-4 h-4 rounded border-slate-300 text-primary focus:ring-primary/30'
