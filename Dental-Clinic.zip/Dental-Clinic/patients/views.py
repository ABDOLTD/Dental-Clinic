from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.db.models import Q
from django.shortcuts import get_object_or_404, redirect, render

from accounts.decorators import role_required
from accounts.models import User
from .forms import PatientForm
from .models import Patient


@login_required
def patient_list(request):
    query = request.GET.get('q', '').strip()
    patients = Patient.objects.all()
    if query:
        patients = patients.filter(
            Q(first_name__icontains=query) | Q(last_name__icontains=query) | Q(phone__icontains=query)
        )
    return render(request, 'patients/patient_list.html', {'patients': patients, 'query': query, 'active_nav': 'patients'})


@login_required
def patient_detail(request, pk):
    patient = get_object_or_404(Patient, pk=pk)
    context = {
        'patient': patient,
        'appointments': patient.appointments.all()[:10],
        'treatment_records': patient.treatment_records.select_related('treatment', 'doctor').all()[:10],
        'invoices': patient.invoices.all()[:10],
        'active_nav': 'patients',
    }
    return render(request, 'patients/patient_detail.html', context)


@role_required(User.Role.ADMIN, User.Role.RECEPTION)
def patient_create(request):
    if request.method == 'POST':
        form = PatientForm(request.POST)
        if form.is_valid():
            patient = form.save()
            messages.success(request, f'{patient.full_name} was added successfully.')
            return redirect('patients:detail', pk=patient.pk)
    else:
        form = PatientForm()
    return render(request, 'patients/patient_form.html', {'form': form, 'active_nav': 'patients', 'title': 'Add Patient'})


@role_required(User.Role.ADMIN, User.Role.RECEPTION)
def patient_edit(request, pk):
    patient = get_object_or_404(Patient, pk=pk)
    if request.method == 'POST':
        form = PatientForm(request.POST, instance=patient)
        if form.is_valid():
            form.save()
            messages.success(request, 'Patient details updated.')
            return redirect('patients:detail', pk=patient.pk)
    else:
        form = PatientForm(instance=patient)
    return render(request, 'patients/patient_form.html', {'form': form, 'active_nav': 'patients', 'title': 'Edit Patient'})


@role_required(User.Role.ADMIN)
def patient_delete(request, pk):
    patient = get_object_or_404(Patient, pk=pk)
    if request.method == 'POST':
        patient.delete()
        messages.success(request, 'Patient record deleted.')
        return redirect('patients:list')
    return render(request, 'patients/patient_confirm_delete.html', {'patient': patient, 'active_nav': 'patients'})
