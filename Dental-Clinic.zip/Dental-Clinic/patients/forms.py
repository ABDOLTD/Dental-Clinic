from django import forms

from dental_clinic.form_utils import INPUT_CLASSES, TEXTAREA_CLASSES
from .models import Patient


class PatientForm(forms.ModelForm):
    class Meta:
        model = Patient
        fields = [
            'first_name', 'last_name', 'date_of_birth', 'gender', 'phone',
            'email', 'address', 'allergies', 'medical_notes',
        ]
        widgets = {
            'first_name': forms.TextInput(attrs={'class': INPUT_CLASSES}),
            'last_name': forms.TextInput(attrs={'class': INPUT_CLASSES}),
            'date_of_birth': forms.DateInput(attrs={'class': INPUT_CLASSES, 'type': 'date'}),
            'gender': forms.Select(attrs={'class': INPUT_CLASSES}),
            'phone': forms.TextInput(attrs={'class': INPUT_CLASSES}),
            'email': forms.EmailInput(attrs={'class': INPUT_CLASSES}),
            'address': forms.TextInput(attrs={'class': INPUT_CLASSES}),
            'allergies': forms.TextInput(attrs={'class': INPUT_CLASSES, 'placeholder': 'e.g. Penicillin, Latex'}),
            'medical_notes': forms.Textarea(attrs={'class': TEXTAREA_CLASSES}),
        }
