from datetime import date

from django.contrib import messages
from django.contrib.auth.decorators import login_required
from django.shortcuts import get_object_or_404, redirect, render

from accounts.decorators import role_required
from accounts.models import User
from .forms import AppointmentForm
from .models import Appointment


@login_required
def appointment_list(request):
    appointments = Appointment.objects.select_related('patient', 'doctor')

    if request.user.is_doctor_role:
        appointments = appointments.filter(doctor=request.user)

    patient_id = request.GET.get('patient')
    if patient_id:
        appointments = appointments.filter(patient_id=patient_id)

    status = request.GET.get('status')
    if status:
        appointments = appointments.filter(status=status)

    day = request.GET.get('date')
    if day:
        appointments = appointments.filter(date=day)

    context = {
        'appointments': appointments,
        'statuses': Appointment.Status.choices,
        'selected_status': status,
        'active_nav': 'appointments',
        'today': date.today(),
    }
    return render(request, 'appointments/appointment_list.html', context)


@login_required
def appointment_detail(request, pk):
    appointment = get_object_or_404(Appointment.objects.select_related('patient', 'doctor'), pk=pk)
    return render(request, 'appointments/appointment_detail.html', {
        'appointment': appointment,
        'treatment_records': appointment.treatment_records.select_related('treatment'),
        'active_nav': 'appointments',
    })


@role_required(User.Role.ADMIN, User.Role.RECEPTION)
def appointment_create(request):
    if request.method == 'POST':
        form = AppointmentForm(request.POST)
        if form.is_valid():
            appointment = form.save(commit=False)
            appointment.created_by = request.user
            appointment.save()
            messages.success(request, 'Appointment scheduled.')
            return redirect('appointments:detail', pk=appointment.pk)
    else:
        form = AppointmentForm(initial={'date': date.today()})
    return render(request, 'appointments/appointment_form.html', {'form': form, 'active_nav': 'appointments', 'title': 'Schedule Appointment'})


@login_required
def appointment_edit(request, pk):
    appointment = get_object_or_404(Appointment, pk=pk)
    if request.user.is_doctor_role and appointment.doctor != request.user:
        messages.error(request, 'You can only update your own appointments.')
        return redirect('appointments:list')

    if request.method == 'POST':
        form = AppointmentForm(request.POST, instance=appointment)
        if form.is_valid():
            form.save()
            messages.success(request, 'Appointment updated.')
            return redirect('appointments:detail', pk=appointment.pk)
    else:
        form = AppointmentForm(instance=appointment)
    return render(request, 'appointments/appointment_form.html', {'form': form, 'active_nav': 'appointments', 'title': 'Edit Appointment'})


@role_required(User.Role.ADMIN, User.Role.RECEPTION)
def appointment_delete(request, pk):
    appointment = get_object_or_404(Appointment, pk=pk)
    if request.method == 'POST':
        appointment.delete()
        messages.success(request, 'Appointment cancelled and removed.')
        return redirect('appointments:list')
    return render(request, 'appointments/appointment_confirm_delete.html', {'appointment': appointment, 'active_nav': 'appointments'})
