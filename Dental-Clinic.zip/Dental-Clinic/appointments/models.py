from django.conf import settings
from django.db import models
from django.urls import reverse

from patients.models import Patient


class Appointment(models.Model):
    class Status(models.TextChoices):
        SCHEDULED = 'SCHEDULED', 'Scheduled'
        COMPLETED = 'COMPLETED', 'Completed'
        CANCELLED = 'CANCELLED', 'Cancelled'
        NO_SHOW = 'NO_SHOW', 'No-show'

    patient = models.ForeignKey(Patient, on_delete=models.CASCADE, related_name='appointments')
    doctor = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.CASCADE, related_name='appointments',
        limit_choices_to={'role': 'DOCTOR'},
    )
    date = models.DateField()
    time = models.TimeField()
    reason = models.CharField(max_length=255)
    status = models.CharField(max_length=20, choices=Status.choices, default=Status.SCHEDULED)
    notes = models.TextField(blank=True)
    created_by = models.ForeignKey(
        settings.AUTH_USER_MODEL, on_delete=models.SET_NULL, null=True, blank=True,
        related_name='booked_appointments',
    )
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        ordering = ['-date', '-time']

    def __str__(self):
        return f'{self.patient} with {self.doctor} on {self.date} {self.time}'

    def get_absolute_url(self):
        return reverse('appointments:detail', args=[self.pk])

    @property
    def status_color(self):
        return {
            self.Status.SCHEDULED: 'bg-blue-100 text-blue-700',
            self.Status.COMPLETED: 'bg-primary/10 text-primary',
            self.Status.CANCELLED: 'bg-rose-100 text-rose-700',
            self.Status.NO_SHOW: 'bg-amber-100 text-amber-700',
        }.get(self.status, 'bg-slate-100 text-slate-700')
