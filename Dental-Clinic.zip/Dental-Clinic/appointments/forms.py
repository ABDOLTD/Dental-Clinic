from django import forms

from accounts.models import User
from dental_clinic.form_utils import INPUT_CLASSES, TEXTAREA_CLASSES
from patients.models import Patient
from .models import Appointment


class AppointmentForm(forms.ModelForm):
    patient = forms.ModelChoiceField(
        queryset=Patient.objects.all(),
        widget=forms.Select(attrs={'class': INPUT_CLASSES}),
    )
    doctor = forms.ModelChoiceField(
        queryset=User.objects.filter(role=User.Role.DOCTOR, is_active=True),
        widget=forms.Select(attrs={'class': INPUT_CLASSES}),
    )

    class Meta:
        model = Appointment
        fields = ['patient', 'doctor', 'date', 'time', 'reason', 'status', 'notes']
        widgets = {
            'date': forms.DateInput(attrs={'class': INPUT_CLASSES, 'type': 'date'}),
            'time': forms.TimeInput(attrs={'class': INPUT_CLASSES, 'type': 'time'}),
            'reason': forms.TextInput(attrs={'class': INPUT_CLASSES}),
            'status': forms.Select(attrs={'class': INPUT_CLASSES}),
            'notes': forms.Textarea(attrs={'class': TEXTAREA_CLASSES}),
        }
