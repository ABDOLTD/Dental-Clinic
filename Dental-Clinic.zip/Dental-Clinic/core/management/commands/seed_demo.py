import random
from datetime import date, timedelta
from decimal import Decimal

from django.core.management.base import BaseCommand
from django.db import transaction

from accounts.models import User
from appointments.models import Appointment
from billing.models import Invoice, Payment
from patients.models import Patient
from treatments.models import Treatment, TreatmentRecord

FIRST_NAMES = [
    'Amara', 'Liam', 'Sofia', 'Noah', 'Layla', 'Omar', 'Maya', 'Yusuf', 'Nadia', 'Karim',
    'Farida', 'Adam', 'Salma', 'Tarek', 'Rania', 'Hassan', 'Dina', 'Ziad', 'Mona', 'Sami',
]
LAST_NAMES = [
    'Haddad', 'Nasser', 'Farouk', 'Aziz', 'Saleh', 'Mansour', 'Khalil', 'Rashid', 'Sabbagh', 'Fahmy',
]
REASONS = [
    'Routine check-up', 'Tooth pain', 'Cleaning appointment', 'Follow-up visit',
    'Cavity check', 'Whitening consultation', 'Wisdom tooth pain', 'Braces adjustment',
]


class Command(BaseCommand):
    help = 'Seed the database with demo staff, patients, appointments, treatments and invoices.'

    @transaction.atomic
    def handle(self, *args, **options):
        random.seed(42)
        today = date.today()

        admin = self._get_or_create_user(
            'admin', 'admin12345', User.Role.ADMIN,
            first_name='Clinic', last_name='Admin', is_staff=True, is_superuser=True,
        )

        receptionists = [
            self._get_or_create_user('reception1', 'demo12345', User.Role.RECEPTION, 'Hana', 'Youssef'),
            self._get_or_create_user('reception2', 'demo12345', User.Role.RECEPTION, 'Layla', 'Amin'),
        ]

        doctors_data = [
            ('drmona', 'Mona', 'Zaki', 'General Dentist'),
            ('drkarim', 'Karim', 'Aboud', 'Orthodontist'),
            ('drsara', 'Sara', 'Elias', 'Oral Surgeon'),
        ]
        doctors = [
            self._get_or_create_user(u, 'demo12345', User.Role.DOCTOR, f, l, specialty=s)
            for u, f, l, s in doctors_data
        ]

        treatments = self._seed_treatments()
        patients = self._seed_patients()

        self._seed_visits(patients, doctors, receptionists, treatments, today)

        self.stdout.write(self.style.SUCCESS(
            f'Seeded {len(patients)} patients, {len(doctors)} doctors, '
            f'{len(receptionists)} receptionists, {len(treatments)} treatments, plus appointments/invoices.'
        ))
        self.stdout.write(self.style.SUCCESS('Login with admin / admin12345 (or any demo account, password demo12345).'))

    def _get_or_create_user(self, username, password, role, first_name='', last_name='', specialty='', **extra):
        user, created = User.objects.get_or_create(username=username, defaults={
            'role': role, 'first_name': first_name, 'last_name': last_name,
            'specialty': specialty, 'email': f'{username}@brightsmile.demo', **extra,
        })
        if created:
            user.set_password(password)
            user.save()
        return user

    def _seed_treatments(self):
        catalog = [
            ('Consultation', Treatment.Category.DIAGNOSTIC, 'Initial exam and diagnosis', '25.00'),
            ('Dental X-Ray', Treatment.Category.DIAGNOSTIC, 'Digital radiograph', '40.00'),
            ('Scaling & Polishing', Treatment.Category.PREVENTIVE, 'Routine cleaning', '60.00'),
            ('Fluoride Treatment', Treatment.Category.PREVENTIVE, 'Cavity prevention coating', '35.00'),
            ('Cavity Filling', Treatment.Category.RESTORATIVE, 'Composite resin filling', '90.00'),
            ('Root Canal Treatment', Treatment.Category.RESTORATIVE, 'Endodontic treatment', '350.00'),
            ('Crown Placement', Treatment.Category.RESTORATIVE, 'Ceramic crown fitting', '450.00'),
            ('Tooth Extraction', Treatment.Category.SURGICAL, 'Simple extraction', '120.00'),
            ('Wisdom Tooth Removal', Treatment.Category.SURGICAL, 'Surgical extraction', '280.00'),
            ('Teeth Whitening', Treatment.Category.COSMETIC, 'In-clinic whitening session', '200.00'),
            ('Braces Consultation', Treatment.Category.ORTHODONTIC, 'Orthodontic assessment', '50.00'),
            ('Braces Adjustment', Treatment.Category.ORTHODONTIC, 'Monthly adjustment', '75.00'),
        ]
        treatments = []
        for name, category, desc, price in catalog:
            treatment, _ = Treatment.objects.get_or_create(
                name=name, defaults={'category': category, 'description': desc, 'default_price': Decimal(price)}
            )
            treatments.append(treatment)
        return treatments

    def _seed_patients(self):
        patients = []
        used_names = set()
        for _ in range(20):
            while True:
                fn, ln = random.choice(FIRST_NAMES), random.choice(LAST_NAMES)
                if (fn, ln) not in used_names:
                    used_names.add((fn, ln))
                    break
            dob = date.today() - timedelta(days=random.randint(6 * 365, 70 * 365))
            patient, _ = Patient.objects.get_or_create(
                first_name=fn, last_name=ln, defaults={
                    'date_of_birth': dob,
                    'gender': random.choice(['M', 'F']),
                    'phone': f'+20 10{random.randint(10000000, 99999999)}',
                    'email': f'{fn.lower()}.{ln.lower()}@example.com',
                    'address': f'{random.randint(1, 200)} Nile Street, Cairo',
                    'allergies': random.choice(['', '', '', 'Penicillin', 'Latex']),
                }
            )
            patients.append(patient)
        return patients

    def _seed_visits(self, patients, doctors, receptionists, treatments, today):
        for patient in patients:
            doctor = random.choice(doctors)
            num_past_visits = random.randint(0, 3)

            for _ in range(num_past_visits):
                visit_date = today - timedelta(days=random.randint(5, 200))
                appt = Appointment.objects.create(
                    patient=patient, doctor=doctor, date=visit_date,
                    time=f'{random.randint(9, 16):02d}:00',
                    reason=random.choice(REASONS), status=Appointment.Status.COMPLETED,
                    created_by=random.choice(receptionists),
                )
                num_treatments = random.randint(1, 2)
                records = []
                for _ in range(num_treatments):
                    treatment = random.choice(treatments)
                    record = TreatmentRecord.objects.create(
                        patient=patient, doctor=doctor, treatment=treatment, appointment=appt,
                        cost=treatment.default_price, date=visit_date,
                    )
                    records.append(record)

                if random.random() < 0.8:
                    invoice = Invoice.objects.create(
                        patient=patient, issued_date=visit_date,
                        due_date=visit_date + timedelta(days=14),
                        created_by=random.choice(receptionists),
                    )
                    invoice.treatment_records.set(records)
                    total = sum((r.cost for r in records), Decimal('0'))
                    payment_roll = random.random()
                    if payment_roll < 0.6:
                        Payment.objects.create(
                            invoice=invoice, amount=total, method=random.choice(Payment.Method.values),
                            date=visit_date + timedelta(days=random.randint(0, 5)),
                            received_by=random.choice(receptionists),
                        )
                    elif payment_roll < 0.85:
                        Payment.objects.create(
                            invoice=invoice, amount=(total / 2).quantize(Decimal('0.01')),
                            method=random.choice(Payment.Method.values),
                            date=visit_date + timedelta(days=random.randint(0, 5)),
                            received_by=random.choice(receptionists),
                        )

            if random.random() < 0.5:
                Appointment.objects.create(
                    patient=patient, doctor=doctor, date=today,
                    time=f'{random.randint(9, 16):02d}:{random.choice(["00", "30"])}',
                    reason=random.choice(REASONS), status=Appointment.Status.SCHEDULED,
                    created_by=random.choice(receptionists),
                )
            if random.random() < 0.4:
                Appointment.objects.create(
                    patient=patient, doctor=doctor, date=today + timedelta(days=random.randint(1, 14)),
                    time=f'{random.randint(9, 16):02d}:00',
                    reason=random.choice(REASONS), status=Appointment.Status.SCHEDULED,
                    created_by=random.choice(receptionists),
                )
