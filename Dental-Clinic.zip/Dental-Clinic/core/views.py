from datetime import date

from django.contrib.auth.decorators import login_required
from django.db.models import Sum
from django.shortcuts import render

from accounts.models import User
from appointments.models import Appointment
from billing.models import Invoice, Payment
from patients.models import Patient
from treatments.models import TreatmentRecord


@login_required
def dashboard(request):
    user = request.user
    today = date.today()
    context = {'active_nav': 'dashboard', 'today': today}

    if user.is_admin_role or user.is_superuser:
        month_revenue = Payment.objects.filter(date__year=today.year, date__month=today.month).aggregate(
            total=Sum('amount')
        )['total'] or 0
        unpaid_invoices = [inv for inv in Invoice.objects.all() if inv.status != 'PAID']
        context.update({
            'patient_count': Patient.objects.count(),
            'today_appointments': Appointment.objects.filter(date=today).select_related('patient', 'doctor'),
            'staff_count': User.objects.filter(is_active=True).count(),
            'doctor_count': User.objects.filter(role=User.Role.DOCTOR, is_active=True).count(),
            'month_revenue': month_revenue,
            'outstanding_balance': sum((inv.balance_due for inv in unpaid_invoices), 0),
            'recent_patients': Patient.objects.order_by('-created_at')[:5],
        })
        return render(request, 'core/dashboard_admin.html', context)

    if user.is_reception_role:
        context.update({
            'today_appointments': Appointment.objects.filter(date=today).select_related('patient', 'doctor'),
            'patient_count': Patient.objects.count(),
            'upcoming_count': Appointment.objects.filter(date__gt=today, status=Appointment.Status.SCHEDULED).count(),
            'unpaid_invoices': [inv for inv in Invoice.objects.all() if inv.status != 'PAID'][:5],
        })
        return render(request, 'core/dashboard_reception.html', context)

    if user.is_doctor_role:
        context.update({
            'today_appointments': Appointment.objects.filter(date=today, doctor=user).select_related('patient'),
            'upcoming_appointments': Appointment.objects.filter(
                date__gt=today, doctor=user, status=Appointment.Status.SCHEDULED
            ).select_related('patient')[:5],
            'recent_records': TreatmentRecord.objects.filter(doctor=user).select_related('patient', 'treatment')[:5],
            'patients_treated': Patient.objects.filter(treatment_records__doctor=user).distinct().count(),
        })
        return render(request, 'core/dashboard_doctor.html', context)

    return render(request, 'core/dashboard_admin.html', context)
